package ex1.lm;

import ex1.common.Model;

public interface ModelCreator {

	Model createModel();

}
