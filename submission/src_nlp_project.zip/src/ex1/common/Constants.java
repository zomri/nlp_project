package ex1.common;

public class Constants {
	public static final String UNK = "<UNK>";
}
